package com.example.touchassist

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.Locale

/** إنشاء/تعديل منطقة الشاشة وإعداداتها الفعلية. */
class RegionEditActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        val region = if (intent.hasExtra("id")) {
            RegionStore.get(this, intent.getStringExtra("id") ?: "") ?: run { finish(); return }
        } else {
            ScreenRegion(
                name = "منطقة ${RegionStore.load(this).size + 1}",
                x = intent.getIntExtra("x", 0),
                y = intent.getIntExtra("y", 0),
                width = intent.getIntExtra("width", 1),
                height = intent.getIntExtra("height", 1)
            )
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(12))
        }

        root.addView(label(if (intent.hasExtra("id")) "تعديل المنطقة" else "اسم المنطقة"))
        val name = EditText(this).apply {
            setSingleLine(true)
            hint = region.name
            setText(region.name)
        }
        root.addView(name, match())

        root.addView(label("حدود المنطقة المحفوظة"))
        root.addView(info("X=${region.x}  Y=${region.y}   ${region.width} × ${region.height} بكسل"))

        root.addView(label("نوع التنفيذ"))
        val action = Spinner(this)
        val actions = arrayOf(
            "نقرة",
            "نقر مع الاستمرار",
            "سحب لأعلى",
            "سحب لأسفل",
            "سحب لليسار",
            "سحب لليمين"
        )
        action.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, actions)
        action.setSelection(
            when (region.action) {
                "hold" -> 1
                "swipe_up" -> 2
                "swipe_down" -> 3
                "swipe_left" -> 4
                "swipe_right" -> 5
                else -> 0
            }
        )
        root.addView(action, match())

        root.addView(label("مدة اللمس / النقر (0–1000 ms)"))
        val tapMs = number(region.tapMs)

        root.addView(label("سرعة اللمس (نقرات/ثانية) — تؤثر مع التكرار"))
        val touchSpeed = number(region.touchSpeed)

        root.addView(label("مدة النقر مع الاستمرار (0–1000 ms)"))
        val holdMs = number(region.holdMs)

        root.addView(label("مدة السحب (0–1000 ms)"))
        val swipeMs = number(region.swipeMs)

        root.addView(label("سرعة السحب (بكسل/ثانية) — 0 = استخدم مدة السحب"))
        val swipeSpeed = number(region.swipeSpeed)

        root.addView(label("عدد التكرار (1–100)"))
        val repeat = number(region.repeat.toDouble(), false)

        root.addView(label("الفاصل بين التكرارات (0–1000 ms)"))
        val delay = number(region.repeatDelay.toDouble(), false)

        root.addView(label("إعدادات أيقونة الكرة (نسخة الكرة فقط)"))
        root.addView(label("مدة النقر على الأيقونة (0–1000 ms)"))
        val iconTap = number(region.iconTapMs)
        root.addView(label("مدة الضغط المطوّل على الأيقونة (0–1000 ms)"))
        val iconLong = number(region.iconLongMs)
        root.addView(label("مهلة الضغطتين على الأيقونة (0–1000 ms)"))
        val iconDouble = number(region.iconDoubleMs)

        root.addView(note(
            "المنطقة نفسها هي المستطيل المحفوظ. التنفيذ يتم عند مركزها. القيم الزمنية تُمرّر إلى Android GestureDescription كمدة فعلية؛ 0 يعني أن التطبيق لا يختار مدة بديلة إلا عندما يكون الصفر غير صالح للـGesture، وأقل مدة تنفيذية هي 1 ms."
        ))

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val save = Button(this).apply {
            text = "حفظ"
            setOnClickListener {
                region.name = name.text.toString().trim().ifEmpty { "منطقة ${RegionStore.load(this@RegionEditActivity).size + 1}" }
                region.action = when (action.selectedItemPosition) {
                    1 -> "hold"
                    2 -> "swipe_up"
                    3 -> "swipe_down"
                    4 -> "swipe_left"
                    5 -> "swipe_right"
                    else -> "tap"
                }
                region.tapMs = parse(tapMs, 50.0).coerceIn(0.0, 1000.0)
                region.touchSpeed = parse(touchSpeed, 1.0).coerceIn(0.0, 1000.0)
                region.holdMs = parse(holdMs, 500.0).coerceIn(0.0, 1000.0)
                region.swipeMs = parse(swipeMs, 100.0).coerceIn(0.0, 1000.0)
                region.swipeSpeed = parse(swipeSpeed, 1000.0).coerceIn(0.0, 100000.0)
                region.repeat = parse(repeat, 1.0).toInt().coerceIn(1, 100)
                region.repeatDelay = parse(delay, 0.0).toLong().coerceIn(0L, 1000L)
                region.iconTapMs = parse(iconTap, 50.0).coerceIn(0.0, 1000.0)
                region.iconLongMs = parse(iconLong, 500.0).coerceIn(0.0, 1000.0)
                region.iconDoubleMs = parse(iconDouble, 300.0).coerceIn(0.0, 1000.0)
                RegionStore.upsert(this@RegionEditActivity, region)
                Toast.makeText(this@RegionEditActivity, "اتحفظت: ${region.name}", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
        buttons.addView(save)

        if (intent.hasExtra("id")) {
            val del = Button(this).apply {
                text = "حذف"
                setOnClickListener {
                    AlertDialog.Builder(this@RegionEditActivity)
                        .setMessage("تمسح المنطقة \"${region.name}\"؟")
                        .setPositiveButton("امسح") { _, _ ->
                            RegionStore.delete(this@RegionEditActivity, region.id)
                            finish()
                        }
                        .setNegativeButton("إلغاء", null)
                        .show()
                }
            }
            buttons.addView(del)
        }
        buttons.addView(Button(this).apply { text = "إلغاء"; setOnClickListener { finish() } })
        root.addView(buttons, match())

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun label(t: String): TextView = TextView(this).apply {
        text = t
        textSize = 14f
        setPadding(0, dp(12), 0, dp(2))
    }

    private fun info(t: String): TextView = TextView(this).apply {
        text = t
        textSize = 13f
        setTextColor(0xFF6B6B70.toInt())
        setPadding(0, dp(4), 0, dp(6))
    }

    private fun note(t: String): TextView = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(0xFF6B6B70.toInt())
        setPadding(0, dp(12), 0, dp(8))
    }

    private fun number(v: Double, decimal: Boolean = true): EditText = EditText(this).apply {
        setSingleLine(true)
        inputType = InputType.TYPE_CLASS_NUMBER or if (decimal) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0
        setText(if (v % 1.0 == 0.0) v.toInt().toString() else String.format(Locale.US, "%.3f", v).trimEnd('0').trimEnd('.'))
    }

    private fun parse(e: EditText, fallback: Double): Double =
        e.text.toString().trim().toDoubleOrNull()?.takeIf { it.isFinite() } ?: fallback
}
