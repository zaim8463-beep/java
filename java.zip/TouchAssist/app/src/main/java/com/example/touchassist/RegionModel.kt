package com.example.touchassist

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** منطقة شاشة محفوظة: مستطيل + إعدادات تنفيذ مستقلة عن الإيماءات. */
class ScreenRegion(
    val id: String = UUID.randomUUID().toString(),
    var name: String = "",
    var x: Int = 0,
    var y: Int = 0,
    var width: Int = 1,
    var height: Int = 1,
    var action: String = "tap", // tap | hold | swipe_up/down/left/right
    var tapMs: Double = 50.0,
    var touchSpeed: Double = 1.0, // taps/sec when repeat > 1
    var holdMs: Double = 500.0,
    var swipeMs: Double = 100.0,
    var swipeSpeed: Double = 1000.0, // px/sec; 0 = use swipeMs
    var repeat: Int = 1,
    var repeatDelay: Long = 0L,
    var iconTapMs: Double = 50.0,
    var iconLongMs: Double = 500.0,
    var iconDoubleMs: Double = 300.0,
    var pinX: Float? = null,
    var pinY: Float? = null
) {
    fun centerX(): Float = x + width / 2f
    fun centerY(): Float = y + height / 2f

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("name", name); put("x", x); put("y", y)
        put("w", width); put("h", height); put("action", action)
        put("tapMs", tapMs); put("touchSpeed", touchSpeed)
        put("holdMs", holdMs); put("swipeMs", swipeMs); put("swipeSpeed", swipeSpeed)
        put("repeat", repeat); put("repeatDelay", repeatDelay)
        put("iconTapMs", iconTapMs); put("iconLongMs", iconLongMs); put("iconDoubleMs", iconDoubleMs)
        if (pinX != null) put("pinX", pinX.toDouble())
        if (pinY != null) put("pinY", pinY.toDouble())
    }

    companion object {
        fun fromJson(o: JSONObject): ScreenRegion = ScreenRegion(
            o.getString("id"),
            o.optString("name", ""),
            o.optInt("x", 0), o.optInt("y", 0),
            o.optInt("w", 1).coerceAtLeast(1), o.optInt("h", 1).coerceAtLeast(1),
            o.optString("action", "tap"),
            o.optDouble("tapMs", 50.0),
            o.optDouble("touchSpeed", 1.0),
            o.optDouble("holdMs", 500.0),
            o.optDouble("swipeMs", 100.0),
            o.optDouble("swipeSpeed", 1000.0),
            o.optInt("repeat", 1),
            o.optLong("repeatDelay", 0L),
            o.optDouble("iconTapMs", 50.0),
            o.optDouble("iconLongMs", 500.0),
            o.optDouble("iconDoubleMs", 300.0),
            if (o.has("pinX")) o.optDouble("pinX").toFloat() else null,
            if (o.has("pinY")) o.optDouble("pinY").toFloat() else null
        )
    }
}

object RegionStore {
    private const val PREF = "touch_assist_regions"
    private const val KEY = "regions"

    private fun sp(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<ScreenRegion> {
        val out = ArrayList<ScreenRegion>()
        val raw = sp(c).getString(KEY, null) ?: return out
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) out.add(ScreenRegion.fromJson(a.getJSONObject(i)))
        } catch (_: Exception) {}
        return out
    }

    fun save(c: Context, list: List<ScreenRegion>) {
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        sp(c).edit().putString(KEY, a.toString()).apply()
    }

    fun upsert(c: Context, r: ScreenRegion) {
        val list = load(c)
        val i = list.indexOfFirst { it.id == r.id }
        if (i >= 0) list[i] = r else list.add(r)
        save(c, list)
    }

    fun get(c: Context, id: String): ScreenRegion? = load(c).firstOrNull { it.id == id }

    fun delete(c: Context, id: String) {
        save(c, load(c).filterNot { it.id == id })
    }
}
