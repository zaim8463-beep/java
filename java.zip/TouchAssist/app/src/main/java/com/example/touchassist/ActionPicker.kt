package com.example.touchassist

import android.app.Activity
import android.app.AlertDialog
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** اختيار إجراء: من القايمة الجاهزة، أو "اكتب هدف بنفسك" (أوامر مكتوبة بيتنفّذوا فعلاً). */
object ActionPicker {

    private const val HELP =
        "اكتب أمر في كل سطر (أو افصل بينهم بـ ;). الأوامر المتاحة:\n" +
            "tap [x y] [مللي] — نقرة. من غير إحداثيات = على الكورة\n" +
            "hold [x y] مللي — ضغطة مطولة\n" +
            "swipe up|down|left|right [مسافة] [مللي] — سحب من الكورة\n" +
            "swipe x1 y1 x2 y2 [مللي] — سحب بإحداثيات\n" +
            "wait مللي — انتظار\n" +
            "home / back / recents / notifications / control / lock / screenshot / power / volume_up / volume_down / mute / camera / siri\n" +
            "open اسم.الحزمة — فتح تطبيق (مثال: open com.whatsapp)\n" +
            "url رابط — فتح رابط\n" +
            "run اسم_إيماءة — تشغيل إيماءة (يفضل تكون آخر أمر)\n" +
            "ضيف *5 في آخر السطر عشان يتكرر 5 مرات. السطر اللي يبدأ بـ # تعليق.\n" +
            "مهم: بيفهم الأوامر دي بس. مش بيفهم كلام عادي (زي \"روح لـ...\")."

    fun show(act: Activity, title: String, includeSelf: Boolean, current: String, onPick: (String) -> Unit) {
        val ids = ArrayList<String>()
        ids.add("none")
        if (includeSelf) ids.add("self")
        ids.add("@write")
        for (x in Actions.pickable(act)) if (x != "none") ids.add(x)
        val labels = ids.map {
            if (it == "@write") "✍️ اكتب هدف / أمر بنفسك…" else Actions.label(act, it)
        }.toTypedArray()
        AlertDialog.Builder(act)
            .setTitle(title)
            .setItems(labels) { _, w ->
                if (ids[w] == "@write") write(act, current, onPick) else onPick(ids[w])
            }
            .show()
    }

    fun write(act: Activity, current: String, onPick: (String) -> Unit) {
        val d = act.resources.displayMetrics.density
        val pad = (16 * d).toInt()
        val initial = if (current.startsWith("cmd:")) current.substring(4) else ""
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad, pad, 0)
        val help = TextView(act)
        help.text = HELP
        help.textSize = 12f
        val et = EditText(act)
        et.setText(initial)
        et.minLines = 4
        et.gravity = Gravity.TOP or Gravity.START
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        box.addView(help)
        box.addView(et)
        val sv = ScrollView(act)
        sv.addView(box)
        AlertDialog.Builder(act)
            .setTitle("اكتب الهدف")
            .setView(sv)
            .setPositiveButton("حفظ") { _, _ ->
                val t = et.text.toString().trim()
                onPick(if (t.isEmpty()) "none" else "cmd:$t")
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
