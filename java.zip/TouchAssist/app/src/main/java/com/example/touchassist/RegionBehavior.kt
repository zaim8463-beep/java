package com.example.touchassist

/** النسخة العادية = false، نسخة الكرة = true. يتم تبديلها عند تجهيز الـZIP الثاني فقط. */
object RegionBehavior {
    const val BUBBLE_MODE = false
}
