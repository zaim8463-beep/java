package com.example.touchassist

import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.os.Build
import android.os.Bundle
import android.view.*
import android.graphics.drawable.GradientDrawable
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * شاشة تحديد المنطقة بنفس فكرة شاشة "إنشاء إيماءة":
 * شاشة كاملة داخل التطبيق، خلفية فاتحة، شريط إجراءات سفلي، وسحب مباشر على الشاشة لتحديد المستطيل.
 */
class RegionSelectorActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        hideBars()

        val root = SelectorView()
        setContentView(root)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    private fun finishSelection(x: Float, y: Float, w: Float, h: Float) {
        if (w < dp(20) || h < dp(20)) {
            Toast.makeText(this, "حدد مساحة أكبر من 20 × 20 بكسل", Toast.LENGTH_SHORT).show()
            return
        }
        val i = Intent(this, RegionEditActivity::class.java).apply {
            putExtra("x", x.toInt())
            putExtra("y", y.toInt())
            putExtra("width", w.toInt())
            putExtra("height", h.toInt())
        }
        startActivity(i)
        finish()
    }

    private inner class SelectorView : FrameLayout(this) {
        private val surface = RegionSurface(context)
        private val bar = LinearLayout(context)
        private var hasSelection = false
        private var left = 0f
        private var top = 0f
        private var right = 0f
        private var bottom = 0f

        init {
            setBackgroundColor(Color.parseColor("#FAFAFC"))
            addView(surface, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

            bar.orientation = LinearLayout.HORIZONTAL
            bar.isClickable = true
            val bg = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.parseColor("#F2F2F7"))
                setStroke(dp(1), Color.parseColor("#D1D1D6"))
            }
            bar.background = bg
            bar.setPadding(dp(6), dp(2), dp(6), dp(2))

            bar.addView(btn("إلغاء", false) { finish() })
            bar.addView(btn("مسح", false) {
                hasSelection = false
                left = 0f; top = 0f; right = 0f; bottom = 0f
                surface.reset()
                surface.invalidate()
            })
            bar.addView(btn("تأكيد", true) {
                if (hasSelection) {
                    finishSelection(left, top, right - left, bottom - top)
                } else {
                    Toast.makeText(this@RegionSelectorActivity, "حدد المنطقة أولًا", Toast.LENGTH_SHORT).show()
                }
            })

            val blp = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(28)
            }
            addView(bar, blp)
        }

        private fun btn(label: String, bold: Boolean, click: () -> Unit): TextView = TextView(context).apply {
            text = label
            textSize = 15f
            setTextColor(Color.parseColor("#007AFF"))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(9), dp(14), dp(9))
            setOnClickListener { click() }
        }

        private inner class RegionSurface(c: Context) : View(c) {
            private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = Color.argb(48, 0, 122, 255)
            }
            private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = dp(3).toFloat()
                color = Color.rgb(0, 122, 255)
            }
            private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(60, 60, 67)
                textSize = dp(15).toFloat()
                textAlign = Paint.Align.CENTER
            }
            private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(142, 142, 147)
                textSize = dp(16).toFloat()
                textAlign = Paint.Align.CENTER
            }
            private var downX = 0f
            private var downY = 0f
            private var curX = 0f
            private var curY = 0f
            private var drawing = false

            fun reset() {
                drawing = false
                downX = 0f; downY = 0f; curX = 0f; curY = 0f
            }

            override fun onTouchEvent(e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.x; downY = e.y
                        curX = downX; curY = downY
                        drawing = true
                        hasSelection = false
                        invalidate()
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        curX = e.x; curY = e.y
                        updateRect()
                        invalidate()
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        curX = e.x; curY = e.y
                        updateRect()
                        hasSelection = rectWidth() >= dp(20) && rectHeight() >= dp(20)
                        drawing = hasSelection
                        invalidate()
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        drawing = false
                        hasSelection = false
                        invalidate()
                        return true
                    }
                }
                return true
            }

            private fun updateRect() {
                left = min(downX, curX)
                top = min(downY, curY)
                right = max(downX, curX)
                bottom = max(downY, curY)
            }

            private fun rectWidth() = right - left
            private fun rectHeight() = bottom - top

            override fun onDraw(c: Canvas) {
                super.onDraw(c)
                if (!hasSelection && !drawing) {
                    val cx = width / 2f
                    val cy = height / 2f
                    c.drawText("اسحب لتحديد منطقة مخصصة", cx, cy - dp(12), hint)
                    c.drawText("بعدها اضغط تأكيد لحفظها", cx, cy + dp(16), hint)
                    return
                }

                c.drawRect(left, top, right, bottom, fill)
                c.drawRect(left, top, right, bottom, border)

                val w = rectWidth().toInt()
                val h = rectHeight().toInt()
                c.drawText("${w} × ${h} بكسل", (left + right) / 2f, (top + bottom) / 2f, text)
            }
        }
    }
}
