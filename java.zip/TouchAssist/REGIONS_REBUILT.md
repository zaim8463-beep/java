# TouchAssist - Screen Regions

This version adds a Screen Regions feature to the original TouchAssist project.

## Normal build
The custom menu contains saved region names. Selecting a region executes its saved action at the region center.

## Bubble build
Selecting a region opens a movable region ball. Tap the ball to fix its position. The region action then executes at the fixed ball position.

Region settings:
- Tap duration: 0-1000 ms
- Touch speed: taps/second (used between repeated taps)
- Hold duration: 0-1000 ms
- Swipe duration: 0-1000 ms
- Swipe speed: pixels/second; 0 means use swipe duration
- Repetitions: 1-100
- Repeat delay: 0-1000 ms

Bubble icon settings:
- Icon tap duration: 0-1000 ms
- Icon long-press duration: 0-1000 ms
- Icon double-tap timeout: 0-1000 ms

Timing is sent to Android Accessibility GestureDescription. Android's minimum executable stroke duration is 1 ms, so a stored 0 ms is not sent as a zero-duration gesture.
